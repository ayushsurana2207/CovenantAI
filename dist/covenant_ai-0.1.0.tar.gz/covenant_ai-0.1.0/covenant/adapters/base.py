"""
Base adapter interface.
"""
from abc import ABC, abstractmethod
from typing import Any
from covenant.models import AgentTrace

class BaseAdapter(ABC):
    """Wraps an agent callable into a testable interface that returns AgentTrace."""
    
    @abstractmethod
    async def run(self, user_input: str, timeout_seconds: int) -> AgentTrace:
        """Run the agent with the given input and return a structured trace."""
        ...

    @classmethod
    @abstractmethod
    def can_handle(cls, agent: Any) -> bool:
        """Return True if this adapter can handle the given agent object."""
        ...

__all__ = ["BaseAdapter"]

