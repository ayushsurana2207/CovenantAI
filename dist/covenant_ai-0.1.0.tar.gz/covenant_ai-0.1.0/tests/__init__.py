"""
Tests for CovenantAI.
"""
